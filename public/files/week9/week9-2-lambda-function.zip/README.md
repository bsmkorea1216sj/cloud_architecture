# Week 9-2 수정 자료

실행: setup-9-2.sh → Lambda 생성(Python 3.12) → lambda_function.py 배포 → 테스트 → 모니터링.

GET /users는 Scan 페이지를 합칩니다. POST는 전체 항목을 교체하며 새 항목은 201, 기존 항목은 200입니다. id·name·email은 필수 문자열입니다. 현재 API Gateway REST 프록시 v1.0 형식 기준입니다. 실제 HTTP URL은 9-3에서 연결합니다.

코랩 직접 핸들러 호출은 Lambda 메트릭에 반영되지 않습니다. Errors=0이어도 반환 statusCode를 검사하세요. 초기화 시간은 Duration과 구분합니다.

cleanup-9-2.sh는 지정 이름의 Lambda·DynamoDB·IAM·로그 그룹을 삭제합니다. 다른 실습에서 사용 중이면 실행하지 마세요. 삭제 확인 후 진행하며, 태그 검색 대신 각 리소스 부재를 검증합니다.
