#!/bin/bash
# Week 9-2: delete only the named lab resources after explicit confirmation.
set -Eeuo pipefail
export AWS_PAGER=""
command -v aws >/dev/null || { echo 'AWS CLI가 필요합니다.' >&2; exit 1; }
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region 2>/dev/null || true)}}"
REGION="${REGION:-ap-northeast-2}"
export AWS_DEFAULT_REGION="$REGION"
aws sts get-caller-identity --query Account --output text
printf '리전: %s\n대상: CloudArchitect-Lab-UsersAPI / CloudArchitect-Lab-Users / CloudArchitect-Lab-LambdaExecutionRole / 해당 로그 그룹\n' "$REGION"
echo '다른 실습에서 재사용 중인 리소스라면 취소하세요.'
read -r -p '위 실습 리소스를 삭제하시겠습니까? (y/N): ' answer
[[ "$answer" =~ ^[Yy]$ ]] || exit 0
trap 'echo "정리 실패: 완료되지 않은 리소스를 확인하세요." >&2' ERR
# Distinguish absent resources from permission/network failures.
exists() {
    local output
    if output=$("$@" 2>&1); then return 0; fi
    if [[ "$output" == *ResourceNotFoundException* || "$output" == *NoSuchEntity* ]]; then return 1; fi
    printf '%s\n' "$output" >&2
    exit 1
}
FUNCTION=CloudArchitect-Lab-UsersAPI
TABLE=CloudArchitect-Lab-Users
ROLE=CloudArchitect-Lab-LambdaExecutionRole
GROUP="/aws/lambda/$FUNCTION"
if exists aws lambda get-function --function-name "$FUNCTION"; then
    aws lambda delete-function --function-name "$FUNCTION"
fi
if exists aws dynamodb describe-table --table-name "$TABLE"; then
    aws dynamodb delete-table --table-name "$TABLE" >/dev/null
    aws dynamodb wait table-not-exists --table-name "$TABLE"
fi
if exists aws iam get-role --role-name "$ROLE"; then
    managed=$(aws iam list-attached-role-policies --role-name "$ROLE" --query 'AttachedPolicies[].PolicyArn' --output text)
    for policy in $managed; do
        aws iam detach-role-policy --role-name "$ROLE" --policy-arn "$policy"
    done
    inline=$(aws iam list-role-policies --role-name "$ROLE" --query 'PolicyNames[]' --output text)
    for policy in $inline; do
        aws iam delete-role-policy --role-name "$ROLE" --policy-name "$policy"
    done
    aws iam delete-role --role-name "$ROLE"
fi
if exists aws logs describe-log-streams --log-group-name "$GROUP" --limit 1; then
    aws logs delete-log-group --log-group-name "$GROUP"
fi
# Verify all four resources. Never equate AccessDenied with absence.
remaining=0
if exists aws lambda get-function --function-name "$FUNCTION"; then remaining=1; fi
if exists aws dynamodb describe-table --table-name "$TABLE"; then remaining=1; fi
if exists aws iam get-role --role-name "$ROLE"; then remaining=1; fi
if exists aws logs describe-log-streams --log-group-name "$GROUP" --limit 1; then remaining=1; fi
if [[ "$remaining" == 1 ]]; then echo '잔여 리소스가 있습니다. 각 콘솔에서 다시 확인하세요.' >&2; exit 1; fi
echo 'Lambda·DynamoDB·IAM 역할·CloudWatch 로그 그룹 부재 확인 완료'
